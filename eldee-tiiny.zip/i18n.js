(()=>{
 'use strict';
 const dictionary=window.ELDEE_TRANSLATIONS,langs=['ru','kk','en'];
 const originals=new WeakMap(),attributes=new WeakMap();
 let saved='ru';try{saved=localStorage.getItem('eldee-language')||'ru'}catch{}
 const requested=new URL(location.href).searchParams.get('lang');
 let lang=langs.includes(requested)?requested:langs.includes(saved)?saved:'ru';
 const attrs=['aria-label','placeholder','title','alt','data-cursor'];
 const normalize=s=>s.trim().replace(/\s+/g,' ');
 function translated(value){const key=normalize(value);return dictionary[key]&&lang!=='ru'?value.replace(value.trim(),dictionary[key][lang]):value;}
 function text(node){if(node.parentElement?.closest('script,style,.language-switch'))return;let entry=originals.get(node);if(!entry||node.data!==entry.last){entry={source:node.data,last:node.data};originals.set(node,entry)}const next=lang==='en'&&node.parentElement?.id==='subservices-title'&&normalize(entry.source)==='Что'?entry.source.replace('Что','What'):translated(entry.source);if(node.data!==next)node.data=next;entry.last=next;}
 function element(el){if(el.closest('.language-switch'))return;let values=attributes.get(el);if(!values){values={};attributes.set(el,values)}for(const key of attrs){if(!el.hasAttribute(key))continue;const current=el.getAttribute(key);if(!values[key]||current!==values[key].last)values[key]={source:current,last:current};const next=translated(values[key].source);if(current!==next)el.setAttribute(key,next);values[key].last=next;}if(el.matches('a[href]')){const href=el.getAttribute('href');if(!href||href.startsWith('#'))return;const url=new URL(href,location.href);if(url.origin===location.origin&&!/\.[a-z0-9]+$/i.test(url.pathname.replace(/\.html$/i,''))){url.searchParams.set('lang',lang);const next=url.pathname+url.search+url.hash;if(href!==next)el.setAttribute('href',next);}}}
 function walk(root){if(root.nodeType===3){text(root);return}if(root.nodeType!==1)return;element(root);const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT);let node;while(node=walker.nextNode()){if(node.nodeType===3)text(node);else element(node);}}
 const switcher=document.createElement('nav');switcher.className='language-switch';switcher.setAttribute('aria-label','Язык / Тіл / Language');
 for(const [code,label,name]of [['ru','RU','Русский'],['kk','KZ','Қазақша'],['en','EN','English']]){const b=document.createElement('button');b.type='button';b.textContent=label;b.lang=code;b.dataset.lang=code;b.setAttribute('aria-label',name);b.addEventListener('click',()=>change(code));switcher.append(b);}
 document.querySelector('.header')?.append(switcher);
 const meta=document.querySelector('meta[name="description"]');const metaSource=meta?.content;
 const observer=new MutationObserver(records=>{observer.disconnect();for(const r of records){if(r.type==='characterData')text(r.target);else if(r.type==='attributes')element(r.target);else for(const n of r.addedNodes)walk(n);}observe();});
 function observe(){observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:attrs});}
 function change(code){lang=code;observer.disconnect();document.documentElement.lang=lang;try{localStorage.setItem('eldee-language',lang)}catch{}const url=new URL(location.href);url.searchParams.set('lang',lang);history.replaceState(null,'',url);walk(document.body);walk(document.querySelector('title'));if(meta)meta.content=translated(metaSource);switcher.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lang===lang)));observe();window.dispatchEvent(new Event('resize'));}
 change(lang);
})();
