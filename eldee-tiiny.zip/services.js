(()=>{
 'use strict';
 const isDetail=document.body.classList.contains('service-page');
 if(isDetail&&!matchMedia('(prefers-reduced-motion:reduce)').matches)document.body.classList.add('motion-on');
 const nodes=document.querySelectorAll('.services-heading,.service-card,.services-end,.process-step,.result-band,.service-contact,.other-services');
 const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target);}}),{threshold:.08});
 nodes.forEach(el=>{el.classList.add('extra-reveal');observer.observe(el);});
 const video=document.querySelector('.team-video'), button=document.querySelector('.video-toggle');
 if(video&&button){
   let manualPause=false,inView=false;
   const sync=()=>{const halted=video.paused;button.setAttribute('aria-pressed',String(halted));button.setAttribute('aria-label',halted?'Воспроизвести видео':'Приостановить видео');button.dataset.cursor=halted?'Смотреть':'Пауза';button.firstElementChild.textContent=halted?'▷':'Ⅱ';button.querySelector('.video-toggle-label').textContent=halted?'Смотреть':'Пауза';};
   const update=()=>{if(inView&&!manualPause&&!document.hidden&&!document.body.classList.contains('motion-off')){video.play().then(sync).catch(sync);}else{video.pause();sync();}};
   new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;update();},{threshold:.1}).observe(video);
   button.addEventListener('click',()=>{manualPause=!video.paused;if(!manualPause&&document.body.classList.contains('motion-off'))document.querySelector('.motion-toggle')?.click();update();});
   document.querySelector('.motion-toggle')?.addEventListener('click',update);
   document.addEventListener('visibilitychange',update);
   video.addEventListener('play',sync);video.addEventListener('pause',sync);
   video.addEventListener('error',()=>{video.closest('.about-film').classList.add('video-unavailable');});
 }
 if(isDetail){
   const progress=()=>{const height=document.documentElement.scrollHeight-innerHeight;document.querySelector('.progress').style.transform=`scaleX(${height>0?scrollY/height:0})`;};
   addEventListener('scroll',progress,{passive:true});progress();
 }
})();
