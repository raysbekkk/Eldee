(()=>{
 'use strict';
 const cursor=document.querySelector('.cursor');
 if(!cursor)return;
 const label=cursor.querySelector('span'),fine=matchMedia('(pointer:fine)');
 let x=0,y=0,cx=0,cy=0,ready=false,frame=0,last=0;
 function updateContrast(){
   if(!ready)return;
   const surface=document.elementFromPoint(cx,cy);
   const panel=document.querySelector('.hero-expanding .scene');
   const bounds=panel?.getBoundingClientRect();
   const overPanel=!!bounds&&cx>=bounds.left&&cx<=bounds.right&&cy>=bounds.top&&cy<=bounds.bottom;
   cursor.classList.toggle('on-red',overPanel||!!surface?.closest('.brief-cta,.service-contact,.next-case,.scene,.case-highlight,.stat:hover,.brand-cell:hover,.service-card:hover,.brief-submit'));
 }
 function draw(now){
   frame=0;
   const dt=last?Math.min(50,now-last):1000/60;
   last=now;
   const ease=document.body.classList.contains('motion-off')?1:1-Math.exp(-dt/85);
   cx+=(x-cx)*ease;cy+=(y-cy)*ease;
   if(Math.abs(x-cx)+Math.abs(y-cy)<.05){cx=x;cy=y;}
   cursor.style.transform=`translate3d(${cx}px,${cy}px,0) translate(-50%,-50%)`;
   updateContrast();
   if(cx!==x||cy!==y)frame=requestAnimationFrame(draw);else last=0;
 }
 function wake(){if(!frame)frame=requestAnimationFrame(draw);}
 document.addEventListener('pointermove',e=>{
   if(!fine.matches||e.pointerType==='touch')return;
   x=e.clientX;y=e.clientY;
   if(!ready){cx=x;cy=y;ready=true;}
   document.body.classList.add('cursor-ready');
   cursor.style.opacity='1';wake();
 },{passive:true});
 document.addEventListener('pointerover',e=>{
   if(!fine.matches||e.pointerType==='touch')return;
   const hit=e.target.closest('a,button,summary,[data-cursor]');
   cursor.classList.toggle('expanded',!!hit);
   cursor.classList.toggle('over-scene',!!e.target.closest('.scene'));
   label.textContent=hit?.dataset.cursor||(hit?.tagName==='SUMMARY'?'Подробнее':'Перейти');
 });
 document.addEventListener('eldee:scene-layout',()=>{if(ready)wake();});
 function hide(){cursor.style.opacity='0';ready=false;last=0;if(frame)cancelAnimationFrame(frame);frame=0;}
 document.documentElement.addEventListener('pointerleave',hide);
 window.addEventListener('blur',hide);
 window.addEventListener('scroll',()=>{if(ready)wake();},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)hide();});
 fine.addEventListener('change',()=>{if(!fine.matches){hide();document.body.classList.remove('cursor-ready');}});
})();
