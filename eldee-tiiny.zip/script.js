(() => {
  'use strict';
  const $ = s => document.querySelector(s);
  const hero = $('.hero'), stage = $('.hero-sticky'), scene = $('.scene'), wrap = $('.scene-wrap');
  const heading = $('.hero-heading'), bottom = $('.hero-bottom'), header = $('.header');
  const canvas = $('canvas'), ctx = canvas.getContext('2d');
  const toggle = $('.motion-toggle');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)'), fine = matchMedia('(pointer: fine)');
  let paused = false, w = 0, h = 0, time = 0, last = 0, frame = 0, dirty = true, visible = true;
  let mx = 0, my = 0, px = -100, py = -100;
  const clamp = (v,a=0,b=1) => Math.max(a,Math.min(b,v));
  const ease = p => p*p*(3-2*p);
  function setMotion(value){paused=value;document.body.classList.toggle('motion-off',value);document.body.classList.toggle('motion-on',!value);toggle.setAttribute('aria-pressed',String(value));toggle.setAttribute('aria-label',value?'Включить анимацию':'Приостановить анимацию');toggle.title=toggle.getAttribute('aria-label');toggle.firstElementChild.classList.toggle('is-play',value);dirty=true;}
  setMotion(paused);
  toggle.addEventListener('click',()=>setMotion(!paused));
  // Full motion is intentional for this presentation; the visible pause control remains available.
  const reveals = document.querySelectorAll('.section-line,.manifesto,.about-grid h2,.about-copy,.stat,.about-end');
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target);}
  }),{threshold:.16});
  reveals.forEach((el,i)=>{el.classList.add('reveal');el.style.setProperty('--delay',el.classList.contains('stat')?((i-4)*.12)+'s':'0s');observer.observe(el);});
  const sceneType = $('.scene-type');
  const sceneTitle = sceneType.firstElementChild, sceneSubtitle = sceneType.lastElementChild;
  const wipe = document.createElement('div');wipe.className='scene-wipe';wipe.setAttribute('aria-hidden','true');scene.append(wipe);
  const timeline = document.createElement('div');timeline.className='scene-timeline';timeline.setAttribute('aria-hidden','true');timeline.innerHTML='<i></i><i></i><i></i>';scene.append(timeline);
  const titles = [['>11','лет на рынке'],['140+','реализованных кейсов'],['3','страны, где мы делаем проекты']];
  let activeShot = -1;
  function size(){const r=canvas.getBoundingClientRect();w=r.width;h=r.height;const d=Math.min(devicePixelRatio||1,1.5);canvas.width=Math.round(w*d);canvas.height=Math.round(h*d);ctx.setTransform(d,0,0,d,0,0);dirty=true;draw(time);}
  new ResizeObserver(size).observe(canvas);
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;},{threshold:0}).observe(scene);
  const points=[];
  for(let j=0;j<31;j++){let ring=[];for(let i=0;i<=88;i++){let a=i/88*Math.PI*2,b=j/31*Math.PI*2;ring.push([(1+.38*Math.cos(b))*Math.cos(a),(1+.38*Math.cos(b))*Math.sin(a),.38*Math.sin(b)]);}points.push(ring);}
  function draw(t){
    if(!w||!h)return;
    ctx.clearRect(0,0,w,h);
    const loop=t%12, shot=Math.floor(loop/4), phase=loop%4, angle=t*Math.PI/6;
    if(activeShot!==shot){activeShot=shot;sceneTitle.textContent=titles[shot][0];sceneSubtitle.textContent=titles[shot][1];scene.dataset.shot=shot;}
    const enter=ease(clamp(phase/.8)),leave=ease(clamp((phase-3.35)/.65));
    sceneType.style.opacity=String(enter*(1-leave));
    sceneType.style.transform=`translate(${mx*8}px,${(1-enter)*h*.2-leave*h*.16+my*5}px) scale(${.88+enter*.12+leave*.08})`;
    wipe.style.transform=`scaleX(${phase<.5?1-ease(phase/.5):ease(clamp((phase-3.55)/.45))})`;
    wipe.style.transformOrigin=phase<.5?'right':'left';
    [...timeline.children].forEach((bar,i)=>bar.style.setProperty('--fill',String(i<shot?1:i===shot?phase/4:0)));
    const scale=Math.min(w*.32,h*.7)*(1+Math.sin(angle*2)*.12), ry=angle+mx*.28, rx=.72+Math.sin(angle)*.4+my*.2;
    const cy=Math.cos(ry),sy=Math.sin(ry),cr=Math.cos(rx),sr=Math.sin(rx);
    if(shot===0){
    for(let j=0;j<points.length;j++){
      ctx.beginPath();let depth=0;
      points[j].forEach(([x,y,z],i)=>{const xx=x*cy+z*sy,zz=-x*sy+z*cy,yy=y*cr-zz*sr,zd=y*sr+zz*cr;const p=3.8/(3.8+zd);const dx=w*.51+xx*scale*p,dy=h*.52+yy*scale*p;depth+=zd;i?ctx.lineTo(dx,dy):ctx.moveTo(dx,dy);});
      ctx.strokeStyle=j%3===0?'rgba(35,0,8,.8)':'rgba(255,235,235,.65)';ctx.lineWidth=j%3===0?1.2:.8;ctx.stroke();
    }
    }else if(shot===1){
      ctx.save();ctx.translate(w/2+mx*15,h/2+my*15);ctx.rotate(-.22+Math.sin(angle)*.12);
      const gap=Math.max(18,w/18), drift=(phase*gap*.7)%gap;
      for(let x=-w;x<w;x+=gap)for(let y=-h;y<h;y+=gap){const wave=Math.sin(x*.015+y*.016-angle*3);ctx.fillStyle=wave>.35?'#fff':'#650017';ctx.beginPath();ctx.arc(x+drift,y+Math.sin(angle+x*.01)*gap*.22,2+((wave+1)/2)*gap*.13,0,Math.PI*2);ctx.fill();}
      ctx.restore();
    }else{
      ctx.save();ctx.translate(w*.5+mx*15,h*.5+my*15);ctx.rotate(angle*.5);
      for(let i=20;i>0;i--){const s=((i+phase/4)%20)/20;ctx.strokeStyle=i%3===0?'#fff':'#6b0018';ctx.lineWidth=1.5;ctx.save();ctx.rotate(s*1.7+angle*.3);ctx.strokeRect(-w*s*.7,-h*s*.7,w*s*1.4,h*s*1.4);ctx.restore();}ctx.restore();
    }
    const r=Math.min(w,h)*.07;ctx.beginPath();ctx.arc(w*.83+Math.sin(angle*2)*r,h*.3+Math.cos(angle*2)*r,r*.5,0,Math.PI*2);ctx.fillStyle='#171717';ctx.fill();
  }
  function scroll(){
    const mobile=innerWidth<=760, initialWidth=innerWidth*(mobile?.75:.38);
    const headingBottom=heading.offsetTop+heading.offsetHeight;
    const initialHeight=Math.max(170,Math.min(260,innerHeight*.26));
    const tiltAllowance=initialWidth*Math.sin(Math.PI/60)/2;
    const sceneTop=headingBottom-8+tiltAllowance;
    stage.style.minHeight=Math.ceil(Math.max(mobile?680:660,sceneTop+initialHeight+tiltAllowance+bottom.offsetHeight+65))+'px';
    wrap.style.top=sceneTop+'px';wrap.style.height=initialHeight+'px';
    const viewport=innerHeight, rect=hero.getBoundingClientRect(), travel=Math.max(1,hero.offsetHeight-stage.offsetHeight);
    let p=paused?0:clamp(-rect.top/travel);const e=ease(clamp(p/.84));
    hero.style.setProperty('--logo-white',String(e));
    heading.inert=p>0;heading.style.pointerEvents=p>0?'none':'';
    hero.classList.toggle('hero-expanding',p>0);
    const width=initialWidth+(innerWidth-initialWidth)*e,height=initialHeight+(stage.offsetHeight-initialHeight)*e;
    scene.style.setProperty('--scene-label-size',Math.max(12,Math.min(width*.033,height*.065,42))+'px');
    scene.style.width=width+'px';scene.style.height=height+'px';document.querySelector('.scene-type').style.fontSize=Math.min(width*.28,height*.42)+'px';
    scene.style.transform=`translateY(${-(wrap.offsetTop+wrap.offsetHeight/2-stage.offsetHeight/2)*e}px) rotate(${-3*(1-e)}deg)`;
    heading.style.transform=`translateY(${-e*95}px)`;heading.style.opacity=String(1-clamp(p*3));bottom.style.opacity=String(1-clamp(p*3));
    header.style.opacity=String(1-clamp(p*3));header.style.pointerEvents=p>.3?'none':'';header.inert=p>.3;
    bottom.inert=p>.3;scene.style.pointerEvents=p>.93?'none':'auto';
    document.dispatchEvent(new Event('eldee:scene-layout'));
    $('.progress').style.transform=`scaleX(${clamp(scrollY/Math.max(1,document.documentElement.scrollHeight-viewport))})`;
  }
  addEventListener('scroll',()=>dirty=true,{passive:true});addEventListener('resize',()=>dirty=true);
  document.addEventListener('pointermove',e=>{if(!fine.matches||e.pointerType==='touch')return;document.body.classList.add('cursor-ready');px=e.clientX;py=e.clientY;const r=scene.getBoundingClientRect();mx=clamp((px-r.left)/r.width,0,1)*2-1;my=clamp((py-r.top)/r.height,0,1)*2-1;});
  document.querySelectorAll('[data-magnetic]').forEach(el=>{el.addEventListener('pointermove',e=>{if(paused||!fine.matches)return;const r=el.getBoundingClientRect();el.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.16}px,${(e.clientY-r.top-r.height/2)*.22}px)`;});el.addEventListener('pointerleave',()=>el.style.transform='');});
  document.addEventListener('visibilitychange',()=>{last=0;if(!document.hidden&&!frame)frame=requestAnimationFrame(tick);});
  function tick(now){frame=0;if(document.hidden)return;const dt=last?Math.min(40,now-last):16;last=now;if(!paused)time+=dt/1000;
    if(dirty){scroll();dirty=false;}
    if(visible&&(!paused||time===0)){draw(time);if(paused)time=.001;}
    frame=requestAnimationFrame(tick);
  }
  size();scroll();draw(0);frame=requestAnimationFrame(tick);
})();



