(()=>{
 'use strict';
 const targets=[['#hero-title em','pkh'],['a.service-card[href*="service-research"]','verity-edit'],['a.service-card[href*="service-creative"]','fahhh_KcgAXfs'],['a.service-card[href*="service-influence"]','movie_1']];
 const AudioEngine=window.AudioContext||window.webkitAudioContext;
 if(!AudioEngine)return;
 let context,active,wanted=null,version=0,enabled=true;
 try{enabled=localStorage.getItem('eldee-sound')!=='off';}catch{}
 const buffers=new Map(),pending=new Map();
 const button=document.createElement('button');
 button.type='button';button.className='sound-toggle';document.body.append(button);
 function sync(){const ready=enabled&&context?.state==='running';button.textContent=ready?'Звук: вкл':'Включить звук';button.setAttribute('aria-label',ready?'Выключить звуки наведения':'Включить звуки наведения');button.setAttribute('aria-pressed',String(ready));button.title=ready?'Нажмите, чтобы отключить звук':'Нажмите один раз, затем наводите курсор или касайтесь элементов';}
 function stop(){version++;if(!active||!context)return;const old=active;active=null;old.gain.gain.cancelScheduledValues(context.currentTime);old.gain.gain.setTargetAtTime(0,context.currentTime,.025);try{old.source.stop(context.currentTime+.15);}catch{}}
 function load(name){if(buffers.has(name))return Promise.resolve(buffers.get(name));if(!pending.has(name))pending.set(name,fetch('assets/sounds/'+name+'.mp3').then(r=>{if(!r.ok)throw Error('Audio unavailable');return r.arrayBuffer();}).then(b=>context.decodeAudioData(b)).then(b=>{buffers.set(name,b);return b;}).catch(()=>null).finally(()=>pending.delete(name)));return pending.get(name);}
 async function play(){if(!wanted||!enabled||(wanted==='pkh'&&heroSoundBlocked())||context?.state!=='running')return;const name=wanted;if(active?.name===name)return;const ticket=++version;const buffer=await load(name);if((name==='pkh'&&heroSoundBlocked())||!buffer||ticket!==version||wanted!==name||!enabled||document.hidden||context.state!=='running')return;stop();const source=context.createBufferSource(),gain=context.createGain();source.buffer=buffer;source.connect(gain);gain.connect(context.destination);gain.gain.setValueAtTime(0,context.currentTime);gain.gain.linearRampToValueAtTime(.35,context.currentTime+.035);active={source,gain,name};source.onended=()=>{source.disconnect();gain.disconnect();if(active?.source===source)active=null;};source.start();}
 function unlock(){if(!enabled)return;if(!context){context=new AudioEngine();context.addEventListener('statechange',()=>{sync();if(context.state==='running')play();});targets.forEach(([,name])=>load(name));}if(context.state!=='running')context.resume().then(()=>{sync();play();}).catch(sync);else play();sync();}
 function heroSoundBlocked(){const hero=document.querySelector('.hero');return !!hero&&hero.getBoundingClientRect().top < -1;}
 function request(name){if(name==='pkh'&&heroSoundBlocked())return;if(wanted!==name)stop();wanted=name;unlock();}
 // Retry on every trusted gesture: mobile browsers can suspend audio again after backgrounding.
 ['pointerdown','pointerup','touchend','click','keydown'].forEach(type=>document.addEventListener(type,e=>{if(!button.contains(e.target))unlock();},{capture:true,passive:true}));
 targets.forEach(([selector,name])=>{const el=document.querySelector(selector);if(!el)return;
 el.addEventListener('pointerenter',e=>{if(e.pointerType!=='touch')request(name);});
 el.addEventListener('pointerleave',e=>{if(e.pointerType!=='touch'&&wanted===name){wanted=null;stop();}});
 el.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')request(name);});
 el.addEventListener('focus',()=>request(name));el.addEventListener('blur',()=>{if(wanted===name){wanted=null;stop();}});
 if(el.matches('em')){el.tabIndex=0;el.setAttribute('role','button');el.setAttribute('aria-label','Креатива — воспроизвести звук');el.addEventListener('click',()=>request(name));el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();request(name);}});}
 else{const wrap=document.createElement('div');wrap.className='service-sound-wrap';el.before(wrap);wrap.append(el);const preview=document.createElement('button');preview.type='button';preview.className='service-sound-preview';preview.textContent='♪ Послушать звук';preview.setAttribute('aria-label','Послушать звук: '+el.querySelector('h3').textContent);preview.addEventListener('click',()=>{stop();wanted=null;request(name);});wrap.append(preview);}
 });
 button.addEventListener('click',()=>{const ready=enabled&&context?.state==='running';enabled=!ready;try{localStorage.setItem('eldee-sound',enabled?'on':'off');}catch{}if(enabled)unlock();else{wanted=null;stop();}sync();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){wanted=null;stop();}else unlock();});window.addEventListener('pagehide',()=>{wanted=null;stop();});
 window.addEventListener('scroll',()=>{if(wanted==='pkh'||active?.name==='pkh'){wanted=null;stop();}},{passive:true});
 sync();unlock();
})();

