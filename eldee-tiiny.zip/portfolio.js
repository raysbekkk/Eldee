(()=>{
 'use strict';
 const nodes=document.querySelectorAll('.brands-heading,.brands-grid,.portfolio-heading,.case-card,.reviews-heading,.review,.case-chapter');
 const reveal=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('entered');reveal.unobserve(e.target);}}),{threshold:.06});
 nodes.forEach(el=>{el.classList.add('portfolio-reveal');reveal.observe(el);});
 const buttons=[...document.querySelectorAll('[data-filter]')],cards=[...document.querySelectorAll('.case-card')];
 buttons.forEach(button=>button.addEventListener('click',()=>{
   const filter=button.dataset.filter;
   buttons.forEach(b=>b.setAttribute('aria-pressed',String(b===button)));
   cards.forEach(card=>{card.hidden=filter!=='all'&&card.dataset.category!==filter;});
   document.querySelector('#case-status').textContent='Показано проектов: '+cards.filter(c=>!c.hidden).length;
 }));
})();
